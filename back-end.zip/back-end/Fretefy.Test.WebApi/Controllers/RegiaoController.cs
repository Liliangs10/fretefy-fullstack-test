﻿using Fretefy.Test.Domain.Entities;
using Fretefy.Test.Domain.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace Fretefy.Test.WebApi.Controllers
{
    [Route("api/regiao")]
    [ApiController]
    public class RegiaoController : ControllerBase
    {
        private readonly IRegiaoService _regiaoService;

        public RegiaoController(IRegiaoService regiaoService)
        {
            _regiaoService = regiaoService;
        }

        [HttpGet]
        public IActionResult List([FromQuery] string terms)
        {
            IEnumerable<Regiao> regioes;
            if (!string.IsNullOrEmpty(terms))
            {
                regiao = _regiaoService.Query(terms);
            } else
            {
                regiao = _regiaoService.List();
            }

            return Ok(regioes);
        }

        [HttpGet("{id}")]
        public IActionResult Get(Guid id)
        {
            var regiao = _regiaoService.GetCidades(id);
            return Ok(regiao);
        }

        [HttpPost]
        public IActionResult Add([FromBody] AddRegiaoRequest data)
        {
            var duplicado = _regiaoService.Query(data.nome);
            if (duplicado.toList().Count > 0)
            {
                return BadRequest("Regiao já existe!");
            }

            var regiao = new Regiao(data.nome, true);

            foreach(var item in data.Cidades)
            {
                var cidade = new RegiaoCidade()
                {
                    Id = Guid.NewGuid(),
                    RegiaoId = regiao.Id,
                    CidadeId = new Guid(item)
                };
                regiao.Cidades.Add(cidade);
            }
            _regiaoService.Add(regiao);
            return Ok();
        }

        [HttpPut]
        public IActionResult Update([FromBody] UpdateRegiao data)
        {
            var regiao = _regiaoService.GetCidades(new Guid(data.Id));
            regiao.Nome = data.Nome;
            _regiaoService.Update(regiao);
            return Ok();
        }

        [HttpPut]
        public IActionResult UpdateStatus([FromBody] UpdateStatus data)
        {
            var regiao = _regiaoService.Get(new Guid(data.Id));
            if (regiao != null)
            {
                regiao.Ativo = data.Ativo;
                _regiaoService.Update(regiao);
            }
            return Ok();
        }

    }
}

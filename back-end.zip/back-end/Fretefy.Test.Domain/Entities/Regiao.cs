﻿using System;
using System.Collections.Generic;

namespace Fretefy.Test.Domain.Entities
{
    public class Regiao : IEntity
    {
        public Regiao()
        {
        
        }

        public Regiao(string nome, bool ativo)
        {
            Id = Guid.NewGuid();
            Nome = nome;
            Cidade = new List<RegiaoCidade>();
            Ativo = ativo;
        }

        public Guid Id { get; set; }

        public string Nome { get; set; }

        public ICollection<RegiaoCidade> Cidades { get; set; }

        public bool Ativo { get; set; }
    }
}

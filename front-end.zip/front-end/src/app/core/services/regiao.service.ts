import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Regiao } from '../models/regiao.model';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';

@Injectable()
export class RegiaoService  {
    apiBase: string;
    constructor(private _http: HttpClient) {
        this.apiBase = environment.base_api;
    }
    
    listRegiao(): Observable<any>{
        return this._http.get<any>(this.apiBase + '/regiao');
    }

    listRegiaoId(id: string): Observable<any>{
        return this._http.get<any>(this.apiBase + `/regiao/${id}`);
    }

    createRegiao(regiao: Regiao): Observable<any>{
        return this._http.post<any>(this.apiBase + '/regiao', regiao);
    }

    updateRegiao(regiao: Regiao): Observable<any>{
        return this._http.put<any>(this.apiBase + '/regiao', regiao);
    }

    listCidade(): Observable<any>{
        return this._http.get<any>(this.apiBase + '/cidade');
    }

}

import { FormControl, FormGroup, Validators } from '@angular/forms';

export class Cidade {

    id: string;
    nome: string;  
    uf: string;
    
    form?: FormGroup;

    constructor(data:any = null){
       
        if(data != null){
            this.id = data.id;
            this.nome = data.nome;
            this.uf = data.uf;
        }

        this.createForm();
    }

    createForm(): void {
        this.form = new FormGroup({
            id: new FormControl({ value: this.id, disabled: true }),
            nome: new FormControl(this.nome, [Validators.required]), 
            uf: new FormControl(this.uf, [Validators.required]), 
        });
    }
}

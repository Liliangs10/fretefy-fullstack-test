import { FormControl, FormGroup, Validators, FormArray } from '@angular/forms';
import { Cidade } from './cidade.model';

export class Regiao {

    id: string;
    nome: string;  
    cidade: [{
        id?: string;
        cidadeId: string;
        regiaoId: string;
      }];
    ativo: boolean;

    form?: FormGroup;

    constructor(data:any = null){
       
        if(data != null){
            this.id = data.id;
            this.nome = data.nome;
            this.cidade = data.cidade ?? [];;
            this.ativo = data.ativo;
        }

        this.createForm();
    }

    createForm(): void {
        this.form = new FormGroup({
            id: new FormControl({ value: this.id, disabled: true }),
            nome: new FormControl(this.nome, [Validators.required]), 
            cidade: new FormArray([]),
            ativo: new FormControl(this.ativo, [Validators.required]),
        });
    }

}

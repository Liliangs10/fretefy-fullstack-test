import {Component, OnInit} from '@angular/core';
import {FormControl} from '@angular/forms';
import {Observable} from 'rxjs';
import {distinct, map, startWith} from 'rxjs/operators';
import { Regiao } from 'src/app/core/models/regiao.model';
import { MatFormField } from '@angular/material/form-field';
import { Cidade } from 'src/app/core/models/cidade.model';
import { ActivatedRoute, Router } from '@angular/router';
import { RegiaoService } from 'src/app/core/services/regiao.service';

@Component({
  selector: 'app-regiao',
  templateUrl: './regiao.component.html',
  styleUrls: ['./regiao.component.scss']
})

export class RegiaoComponent implements OnInit {
  regiao: Regiao;
  cidade: Cidade;
  regiaoList: Array<Regiao>;
  cidadeList: Array<Cidade>;
  id: string;
  state: string;
  public state$: Observable<string[]>;
  public cidades$: Observable<Cidade[]>;
  public cityList$: Observable<Cidade[]>;

  constructor(private _router: Router,
    private _regiaoService: RegiaoService,
    private _route: ActivatedRoute,        
  ) {
    this._route.params.subscribe(params => {
      this.id = params['id'];
  });
}

ngOnInit() {
  this.editOrCreate();
}


editOrCreate(): void{
  this.regiao = new Regiao();

  if(this.id){
      this.getRegiao(this.id);
  } 
}

getRegiao(id: string): void{
  this._regiaoService.listRegiaoId(id).subscribe((response) => {
      this.regiaoList = response;
  });
  this._regiaoService.listCidade().subscribe((cidades) => {
    this.cityList$ = cidades;
  });
}

submit(): void{
  if (this.regiao) {
      const formToSend = Object.assign(this.regiao.form.getRawValue());
      if (formToSend.cidades.length > 0) {
        formToSend.cidades = formToSend.cidades.map((x) => (x = x.id));
        var temIgual = formToSend.cidades.some(function (item, idx) {
          return formToSend.cidades.indexOf(item) != idx;
        });
        if (temIgual) {
          return;
        } else {
          this.addCity(formToSend.cidades.id);
        }
      }
      this._regiaoService.createRegiao(formToSend).subscribe(() => {
          this._router.navigate(['/regiao']);
      }, () => {
    });
  }
}

update(): void{
  if (this.regiao) {
      const formToSend = Object.assign(this.regiao.form.getRawValue());
      if (formToSend.cidades.length == 0) {
        this.regiao.cidade.map((x: any) => {
          formToSend.cidades.push(x.cidadeId);
        });
      this._regiaoService.updateRegiao(formToSend).subscribe(() => {
          this._router.navigate(['/regiao']);
      }, () => { });
    }
  }
}

addCity(id?: string) {
  this.cidadeList.push(new Cidade(id));
}

selectState(state) {
  this.cidade = <Cidade>{};
  this.cidades$ = this.cityList$.pipe(
    map((x: Cidade[]) => x.filter((y) => y.uf == state))
  );
}


}

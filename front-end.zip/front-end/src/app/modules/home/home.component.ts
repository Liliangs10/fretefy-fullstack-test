import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Regiao } from 'src/app/core/models/regiao.model';
import { RegiaoService } from 'src/app/core/services/regiao.service';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  
  stateList : Array<Regiao>;
  displayedColumns: ['nome', 'ativo', 'action'];
  constructor(
    private _router: Router,
    private _stateService: RegiaoService
  ) { }

  ngOnInit() {
    this.stateList = new Array<Regiao>();
    this._stateService.listRegiao().subscribe(c => {
      this.stateList = c;
    })
  }

  addRegiao(){
    this._router.navigate(['/regiao/new']);
  }

  editRegiao(regiao: Regiao): void{
    this._router.navigate(['/regiao/edit', regiao.id]);
  }
}

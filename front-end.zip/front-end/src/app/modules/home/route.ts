import { RouterModule, Routes } from '@angular/router';
import { RegiaoComponent } from '../regiao/regiao.component';

export const routes: Routes = [
  { 
    path: '',
    component: RegiaoComponent,
    data: { pathFull: 'regiao' }
  },

  {
    path: 'new',
    component: RegiaoComponent,
    data: { pathFull: 'regiao/new' }
},
{
    path: 'edit/:id',
    component: RegiaoComponent,
    data: { pathFull: 'regiao/edit/:id' }
}  
];
